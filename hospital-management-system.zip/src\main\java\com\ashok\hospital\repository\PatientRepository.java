package com.ashok.hospital.repository;

import com.ashok.hospital.model.Patient;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PatientRepository extends MongoRepository<Patient, String> {
}