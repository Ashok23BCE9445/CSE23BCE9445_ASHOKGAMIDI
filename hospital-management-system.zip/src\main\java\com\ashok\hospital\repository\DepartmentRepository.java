package com.ashok.hospital.repository;

import com.ashok.hospital.model.Department;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DepartmentRepository extends MongoRepository<Department, String> {
}